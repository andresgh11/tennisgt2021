This template / effect / code has been created by Liam.
You can customize and check it out on its original site on the following link:
https://codepen.io/liamj/pen/yrEXNx

Thank you